<?php
require 'database.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $long_url = trim($_POST['long_url']);

    if (filter_var($long_url, FILTER_VALIDATE_URL)) {
        $stmt = $pdo->prepare("SELECT short_url FROM urls WHERE long_url = ?");
        $stmt->execute([$long_url]);
        $existing = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($existing) {
            $short_url = $existing['short_url'];
        } else {   
            $short_url = substr(md5(uniqid(rand(), true)), 0, 6);
            $stmt = $pdo->prepare("INSERT INTO urls (long_url, short_url) VALUES (?, ?)");
            $stmt->execute([$long_url, $short_url]);
        }

        $message = "Short URL: <a href='redirect.php?code=$short_url' target='_blank' style='color:#4A00E0; font-weight:bold;'>localhost/url/$short_url</a>";
    } else {
        $message = "<span style='color: red;'>Invalid URL. Please enter a valid URL.</span>";
    }
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Short URL Generator</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #74ebd5, #ACB6E5);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
        }
        h1 {
            color: #ffffff;
            font-size: 36px;
            margin-bottom: 20px;
        }
        form {
            background: #ffffff;
            padding: 40px 30px;
            border-radius: 16px;
            box-shadow: 0px 10px 25px rgba(0, 0, 0, 0.2);
            display: flex;
            flex-direction: column;
            align-items: center;
            min-width: 350px;
        }
        input[type="text"] {
            width: 100%;
            padding: 14px;
            margin-bottom: 20px;
            border: 2px solid #d1d5db;
            border-radius: 10px;
            font-size: 16px;
            transition: 0.3s;
        }
        input[type="text"]:focus {
            border-color: #4A00E0;
            outline: none;
        }
        button {
            padding: 12px 30px;
            border: none;
            background: #4A00E0;
            color: #ffffff;
            border-radius: 10px;
            font-size: 18px;
            cursor: pointer;
            transition: background 0.3s;
        }
        button:hover {
            background: #8E2DE2;
        }
        .short-url-box {
            margin-top: 25px;
            background: #ffffff;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0px 5px 15px rgba(0,0,0,0.1);
            text-align: center;
            font-size: 18px;
        }
        .short-url-box a {
            text-decoration: none;
            color: #4A00E0;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <h1>Short URL Generator</h1>

    <form method="POST">
    <input type="text" name="long_url" placeholder="Enter your long URL" required style="width: 300px;" value="<?php echo isset($_POST['long_url']) ? htmlspecialchars($_POST['long_url']) : ''; ?>">
    <div style="margin-top: 10px;">
        <button type="submit" style="padding: 10px 20px; background-color: #4CAF50; color: white; border: none; border-radius: 6px; cursor: pointer;">Submit</button>

        <button type="button" onclick="window.location.href=window.location.href" style="padding: 10px 20px; background-color: #f44336; color: white; border: none; border-radius: 6px; margin-left: 10px; cursor: pointer;">Clear</button>
    </div>
</form>


    <?php if (!empty($message)): ?>
        <div class="short-url-box">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

</body>
</html>
