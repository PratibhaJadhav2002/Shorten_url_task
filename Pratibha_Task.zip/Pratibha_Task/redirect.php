<?php
require 'database.php'; 
if (isset($_GET['code'])) {
    $short_url = $_GET['code'];


    $stmt = $pdo->prepare("SELECT long_url FROM urls WHERE short_url = ?");
    $stmt->execute([$short_url]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result) {
        header("Location: " . $result['long_url']);
        exit();
    } else {
        echo "Short URL not found.";
    }
} else {
    echo "No short code provided.";
}
?>
